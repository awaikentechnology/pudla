<?php
/**
 * Add Featured Recipes Shortcode
 *
 */
if ( ! function_exists( 'pudla_featured_recipes_shortcode' ) ) {
	function pudla_featured_recipes_shortcode( $atts ) {
		$ids	=	$atts['ids'];
		if(empty($ids)) return;
		$id = explode(",",$ids);
		$query = array(
			'post_type'      => 'pudla_recipe',
			'post__in'      => $id,
		);
		$recipe_query = new WP_Query( $query );
		if ( ! $recipe_query->have_posts() ) {
			return;
		}
		ob_start();
		?>
		<div class="recipe-featured-shortcode">
			<h3><?php echo esc_html($atts['title']); ?></h3>
			<div class="row">
			<?php while ( $recipe_query->have_posts() ): $recipe_query->the_post(); ?>
			<div class="col-md-6">
				<div class="post-box">
					<div class="post-header">
						<?php if ( has_post_thumbnail() ) : ?>
							<a href="<?php the_permalink(); ?>">
								<figure>
									<?php the_post_thumbnail('pudla-thumb'); ?>
								</figure>
							</a>
						<?php endif; ?>
						
						<?php 
						$cook_time = get_post_meta( get_the_ID(), 'pudla_cooking_time', true );
						if(!empty($cook_time)){
						?>
						<div class="cook-time"> 
							<span><?php echo esc_html($cook_time); ?> <?php esc_html_e( 'Min', 'pudla' ); ?></span>
						</div>
						<?php } ?>
					</div>
					
					<div class="post-body">
						<div class="post-entry">
							<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' ); ?>
							<a href="<?php echo esc_url( get_permalink() ); ?>" class="btn-read-recipe">
								<?php esc_html_e( 'Read Recipe', 'pudla' ); ?>
							</a>
						</div>
					</div>
				</div>
			</div>
			<?php endwhile;
			wp_reset_postdata(); ?>
			</div>
		</div>
		<?php
		$return = ob_get_clean();
		return $return;
	}
}
add_shortcode( 'featured_recipes', 'pudla_featured_recipes_shortcode' );

if ( ! function_exists( 'pudla_recipe_detail_box_shortcode' ) ) {
	function pudla_recipe_detail_box_shortcode( $atts ) {
		$return = '';
		
		$default_nutritions = array(
			"calories" => "calories",
			"protein" => "proteinContent",
			"fat" => "fatContent",
			"carbohydrates" => "carbohydrateContent",
			"carbs" => "carbohydrateContent",
			"saturated fat" => "saturatedFatContent",
			"sat_fat" => "saturatedFatContent",
			"trans_fat" => "transFatContent",
			"cholesterol" => "cholesterolContent",
			"fiber" => "fiberContent",
			"sodium" => "sodiumContent",
			"sugar" => "sugarContent");

		
		$pudla_ingredients = get_post_meta( get_the_ID(), 'pudla_ingredients', true );
		$pudla_ingredients_array = array();
		if( $pudla_ingredients ):
			$pudla_ingredients_array =  explode("\n", $pudla_ingredients);
		endif;
		
		$pudla_cooking_equipment = get_post_meta( get_the_ID(), 'pudla_cooking_equipment', true );
		$pudla_cooking_equipment_array = array();
		if( $pudla_cooking_equipment ):
			$pudla_cooking_equipment_array =  explode("\n", $pudla_cooking_equipment);
		endif;
		
		ob_start();
		?>
		<div class="recipe-shortcode">
			<h3 class="recipe-title"><?php the_title(); ?></h3>
			
			<div class="recipe-general-info">
				<div class="row mt-5">
					<div class="col-md-9">
					
						<?php 
						$prep_time = get_post_meta( get_the_ID(), 'pudla_prep_time', true );
						if(!empty($prep_time)):
						?>
						<div class="recipe-info-box">
							<div class="icon-box">
								<i class="flaticon-crossed-knife-and-fork"></i>
							</div>
							<h4><?php esc_html_e( 'Prep Time', 'pudla-recipe' ); ?></h4>
							<p itemprop="prepTime" content="PT<?php echo esc_attr( $prep_time ) ?>M"><?php printf( __( '%s Min', 'pudla-recipe' ), $prep_time ); ?></p>
						</div>
						<?php endif; ?>
						
						<?php 
						$cook_time = get_post_meta( get_the_ID(), 'pudla_cooking_time', true );
						if(!empty($cook_time)):
						?>
						<div class="recipe-info-box">
							<div class="icon-box">
								<i class="flaticon-food-1"></i>
							</div>
							<h4><?php esc_html_e( 'Cooking Time', 'pudla-recipe' ); ?></h4>
							<p itemprop="cookTime" content="PT<?php echo esc_attr( $cook_time ) ?>M"><?php printf( __( '%s Min', 'pudla-recipe' ), $cook_time ); ?></p>
						</div>
						<?php
						endif;
						?>

						<?php 
							$difficulty = get_post_meta( get_the_ID(), 'pudla_difficulty', true );
						?>
						<div class="recipe-info-box">
							<div class="icon-box">
								<i class="flaticon-chef"></i>
							</div>
							<h4><?php esc_html_e( 'Difficulty', 'pudla-recipe' ); ?></h4>
							<p><?php echo esc_html($difficulty); ?></p>
						</div>
						
						<?php 
						$servings = get_post_meta( get_the_ID(), 'pudla_servings', true );
						if(!empty($servings)):
						?>
						<div class="recipe-info-box">
							<div class="icon-box">
								<i class="flaticon-tray"></i>
							</div>
							<h4><?php esc_html_e( 'Serves', 'pudla-recipe' ); ?></h4>
							<p>
							<?php 
								printf( _n( '%s Person', '%s People', $servings, 'pudla-recipe' ), number_format_i18n( $servings ) );
							?>
							</p>
						</div>
						<?php 
						endif;
						?>
						
						<?php 
						$yield = get_post_meta( get_the_ID(), 'pudla_yield', true );
						if(!empty($yield)):
						?>
						<div class="recipe-info-box">
							<div class="icon-box">
								<i class="flaticon-salad"></i>
							</div>
							<h4><?php esc_html_e( 'Yield', 'pudla-recipe' ); ?></h4>
							<p itemprop="recipeYield"><?php echo esc_html($yield); ?></p>
						</div>
						<?php 
						endif;
						?>
						
					</div>
					
					<div class="col-md-3">
						<div class="recipe-print-button">
							<?php if( true == get_theme_mod( 'show_print_recipe_button', true ) ){ ?>
							<a href="#" rel="noindex, nofollow" onclick = "window.print(); return false;"><?php esc_html_e( 'Print Recipe', 'pudla-recipe' ); ?></a>
							<?php } ?>
							<?php if( true == get_theme_mod( 'show_email_recipe_button', true ) ){ ?>
							 <a rel="noindex, nofollow" href="<?php echo 'mailto:?Subject='.get_the_title().'&amp;Body=%20'.get_permalink(); ?>" target="_blank" class=""><?php esc_html_e( 'Email Recipe', 'pudla-recipe' ); ?></a>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
			
			<?php
			if ( function_exists( 'have_rows' ) ) {
				if( have_rows('pudla_nutritional_information') ):
				?>
				<div class="row mt-4">
					<div class="col-md-12">
						<div class="nutrition-box" itemprop="nutrition"  itemscope itemtype="http://schema.org/NutritionInformation">
						<?php
							while ( have_rows('pudla_nutritional_information') ) : the_row();
							$google_rich_meta_field = '';
							if(get_sub_field('pudla_google_rich_meta_field')){
								$google_rich_meta_field = get_sub_field('pudla_google_rich_meta_field');
							}else{
								// Try to find a matching nutrition name for google rich
								$pudla_nutrition_name = get_sub_field('pudla_nutrition_name');
								if(!empty($pudla_nutrition_name)){
									$key = strtolower(str_replace(' ', '_', $pudla_nutrition_name));
									if(isset($default_nutritions[$key])){
										$google_rich_meta_field = $default_nutritions[$key];
									}
								}
							}
							
						?>
							<div class="nutrition-single" itemprop="<?php echo esc_attr( $google_rich_meta_field ); ?>">
								<h4><?php the_sub_field('pudla_nutrition_value'); ?></h4>
								<p><?php the_sub_field('pudla_nutrition_name'); ?></p>
							</div>
						<?php 
							endwhile;
						?>
						</div>
					</div>
				</div>
				<?php
				endif;
			}
			?>
			
			<?php if( 'list-layout' == get_theme_mod( 'recipe_detail_box_layout', 'list-layout' ) ){
				/* List Layout */
			?>
			<div class="row mt-5">
				<div class="col-md-12">
				
					<?php if(count($pudla_ingredients_array)>0){ ?>
					<div class="recipe-information-list-view">
						<h3><i class="flaticon-oat"></i> <?php esc_html_e( 'Ingredients', 'pudla-recipe' ); ?></h3>
						<div class="recipe-information-list-view-entry">
							<ul>
								<?php foreach ( $pudla_ingredients_array as $ingredient ) : ?>
									<?php if ( $ingredient ) : ?>
										<li><span itemprop="recipeIngredient"><?php echo sanitize_text_field($ingredient); ?></span></li>
									<?php endif; ?>
								<?php endforeach; ?>
							</ul>
						</div>
					</div>
					<?php } ?>
					
					<?php if ( function_exists( 'the_field' ) ) { ?>
					<?php if ( get_field('pudla_instructions') ) { ?>
					<div class="recipe-information-list-view">
						<h3><i class="flaticon-check-list"></i> <?php esc_html_e( 'Instructions', 'pudla-recipe' ); ?></h3>
						<div class="recipe-information-list-view-entry">
							<?php the_field('pudla_instructions'); ?>
						</div>
					</div>
					<?php }	?>
					<?php }	?>
					
					<?php if(count($pudla_cooking_equipment_array)>0){ ?>
					<div class="recipe-information-list-view">
						<h3><i class="flaticon-cutlery"></i> <?php esc_html_e( 'Cooking Equipment', 'pudla-recipe' ); ?></h3>
						<div class="recipe-information-list-view-entry">
							<ul>
								<?php foreach ( $pudla_cooking_equipment_array as $equipment ) : ?>
									<?php if ( $equipment ) : ?>
										<li><?php echo sanitize_text_field($equipment); ?></li>
									<?php endif; ?>
								<?php endforeach; ?>
							</ul>
						</div>
					</div>
					<?php } ?>
					
				</div>
			</div>
			<?php }else{ 
				/* Tab Layout */
			?>
			<div class="row mt-5">
				<div class="col-md-12">
					<div class="recipe-information-tabs">
						<ul class="nav nav-tabs responsive" id="myTab" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" id="ingredients-tab" data-toggle="tab" href="#ingredients" role="tab" aria-controls="ingredients" aria-selected="true"><i class="flaticon-oat"></i> <?php esc_html_e( 'Ingredients', 'pudla-recipe' ); ?></a>
							</li>
							
							<li class="nav-item">
								<a class="nav-link" id="instructions-tab" data-toggle="tab" href="#instructions" role="tab" aria-controls="instructions" aria-selected="false"><i class="flaticon-check-list"></i> <?php esc_html_e( 'Instructions', 'pudla-recipe' ); ?></a>
							</li>
							
							<li class="nav-item">
								<a class="nav-link" id="equipment-tab" data-toggle="tab" href="#equipment" role="tab" aria-controls="equipment" aria-selected="false"><i class="flaticon-cutlery"></i> <?php esc_html_e( 'Cooking Equipment', 'pudla-recipe' ); ?></a>
							</li>
						</ul>
						
						<div class="tab-content responsive" id="myTabContent">
							<div class="tab-pane fade show active" id="ingredients" role="tabpanel" aria-labelledby="ingredients-tab">
								<?php if(count($pudla_ingredients_array)>0){ ?>
								<ul>
									<?php foreach ( $pudla_ingredients_array as $ingredient ) : ?>
										<?php if ( $ingredient ) : ?>
											<li><span itemprop="recipeIngredient"><?php echo sanitize_text_field($ingredient); ?></span></li>
										<?php endif; ?>
									<?php endforeach; ?>
								</ul>
								<?php } ?>
							</div>
							
							<div class="tab-pane fade" id="instructions" role="tabpanel" aria-labelledby="instructions-tab" itemprop="recipeInstructions">
							<?php
								if ( function_exists( 'the_field' ) ) {
									the_field('pudla_instructions');
								}
							?>
							</div>
							
							<div class="tab-pane fade" id="equipment" role="tabpanel" aria-labelledby="equipment-tab">
								<?php 
								if(count($pudla_cooking_equipment_array)>0){ ?>
								<ul>
									<?php foreach ( $pudla_cooking_equipment_array as $equipment ) : ?>
										<?php if ( $equipment ) : ?>
											<li><?php echo sanitize_text_field($equipment); ?></li>
										<?php endif; ?>
									<?php endforeach; ?>
								</ul>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php } ?>
		</div>
		<?php
		if ( function_exists( 'the_field' ) ) {
			if(get_field('pudla_notes')){ ?>
				<div class='recipe-note'>
					<p>
						<b><?php esc_html_e( 'Note:', 'pudla-recipe' ); ?></b>
						<?php echo get_field('pudla_notes'); ?>
					</p>
				</div>
			<?php }
		}
		
		$return = ob_get_clean();
		return $return;
	}
}
add_shortcode( 'pudla_recipe_detail_box', 'pudla_recipe_detail_box_shortcode' );