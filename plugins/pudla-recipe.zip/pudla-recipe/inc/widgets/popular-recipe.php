<?php
/**
 * Popular Recipe
 * Display popular recipe on sidebar
 *
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// Register and load the widget
function pudla_popular_recipes() {
	register_widget( 'pudla_popular_recipes_widget' );
}
add_action( 'widgets_init', 'pudla_popular_recipes' );

// Creating the widget 
class pudla_popular_recipes_widget extends WP_Widget {

	/**
	 * Widget setup.
	 */
	 
	 function __construct() {
		
		parent::__construct(
		 
		// Base ID of widget
		'pudla_popular_recipes_widget', 
		 
		// Widget name will appear in UI
		esc_html__('.Pudla: Popular Recipe', 'pudla-recipe' ), 
		 
		// Widget description
		array( 'description' => esc_html__( "A widget that displays an Popular Recipe. Required kk Star Ratings plugin to be installed.", 'pudla-recipe' ), ) 
		);
		
	}

	/**
	 * Creating widget front-end
	 */
	function widget( $args, $instance ) {
		
		extract( $args );
		global $wpdb;

		$title     = apply_filters( 'widget_title', isset( $instance['title'] ) ? $instance['title'] : '' );
		$numberofpost   = $instance['numberofpost'];
		$sr = ($instance['showrating']) ? true : false;
		$showimage = ($instance['showimage']) ? true : false;

		echo wp_kses_post( $before_widget );

		if ( $title )			echo wp_kses_post( $before_title . $title . $after_title );
		
            $table = $wpdb->prefix . 'postmeta';
            $best = get_option('kksr_stars');
            $q = "SELECT a.ID, a.post_title, ROUND(b.meta_value * %f, 1) AS 'ratings' FROM " . $wpdb->posts . " a, $table b, ";
			
			$query = $wpdb->prepare("$q $table c WHERE post_type='pudla_recipe' AND a.post_status='publish' AND a.ID=b.post_id AND a.ID=c.post_id AND b.meta_key='_kksr_avg' AND c.meta_key='_kksr_casts' ORDER BY CAST(b.meta_value AS UNSIGNED) DESC, CAST(c.meta_value AS UNSIGNED) DESC LIMIT %d", $best / 5, $numberofpost);
			$rated_posts = $wpdb->get_results($query);
		
			if(count($rated_posts) > 0 ){ ?>
			<ul>
			<?php 
				foreach ($rated_posts as $post)
				{
					?>
					<li>
						<div class="related-post-block">
							<div class="related-post-image">
								<a href="<?php echo get_permalink($post->ID); ?>">
								<?php if(get_the_post_thumbnail_url($post->ID) && $showimage){ ?>
								<figure>
									<img src="<?php echo get_the_post_thumbnail_url($post->ID); ?>" />
								</figure>
								<?php } ?>
								</a>
							</div>
						
							<div class="related-post-entry">
								<h4><?php echo sanitize_text_field($post->post_title); ?></h4>
								<?php if($sr && $best != false){ ?>
								<?php echo '<span class="related-rating">('.$post->ratings.'/'.$best.')</span>'; ?>
								<?php } ?>
							</div>
						</div>
					</li>
					<?php 
				}
				?>
			</ul>
			<?php 
			}
			else{ 
			?>
					<ul><li><?php esc_html_e( 'No Recipe were found.', 'pudla-recipe' ); ?></li></ul>
			<?php 
			}

		echo wp_kses_post( $after_widget );
	}

	/**
	 * Update the widget settings.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		$instance['title']			= strip_tags( $new_instance['title'] );
		$instance['numberofpost']   = absint( $new_instance['numberofpost'] );
		$instance['showrating'] 	= $new_instance['showrating'];
		$instance['showimage']   	= $new_instance['showimage'];
		
		return $instance;
	}


	function form( $instance ) {
		
		/* Set up some default widget settings. */
		$defaults = array( 'title' => 'Popular Recipe', 'numberofpost' => '5', 'showrating' => 1 , 'showimage' => 1);
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<!-- Widget Title -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'pudla-recipe' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo sanitize_text_field( $instance['title'] ); ?>" />
		</p>
		
		<!-- Number of post -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'numberofpost' ) ); ?>"><?php esc_html_e( 'Number of posts to show:', 'pudla-recipe' ); ?></label>
			<input class="widefat" type="number" step="1" min="1" max="10" size="3" id="<?php echo esc_attr( $this->get_field_id( 'numberofpost' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'numberofpost' ) ); ?>" value="<?php echo esc_attr( $instance['numberofpost'] ); ?>" />
		</p>
		
		<p>
            <label for="<?php echo esc_attr($this->get_field_id('showrating')); ?>"><?php esc_html_e( 'Show Average?:', 'pudla-recipe' ); ?>
            <select id="<?php echo esc_attr($this->get_field_id('showrating')); ?>" name="<?php echo esc_attr($this->get_field_name('showrating')); ?>">
                <option value="0" <?php if(isset($instance['showrating']) && !esc_attr($instance['showrating'])){echo "selected='selected'";} ?>><?php esc_html_e( 'No', 'pudla-recipe' ); ?></option>
                <option value="1" <?php if(isset($instance['showrating']) && esc_attr($instance['showrating'])){echo "selected='selected'";} ?>><?php esc_html_e( 'Yes', 'pudla-recipe' ); ?></option>
            </select>
            </label>
        </p>
		
		<p>
            <label for="<?php echo esc_attr($this->get_field_id('showimage')); ?>"><?php esc_html_e( 'Show Image?:', 'pudla-recipe' ); ?>
            <select id="<?php echo esc_attr($this->get_field_id('showimage')); ?>" name="<?php echo esc_attr($this->get_field_name('showimage')); ?>">
                <option value="0" <?php if(isset($instance['showimage']) && !esc_attr($instance['showimage'])){echo "selected='selected'";} ?>><?php esc_html_e( 'No', 'pudla-recipe' ); ?></option>
                <option value="1" <?php if(isset($instance['showimage']) && esc_attr($instance['showimage'])){echo "selected='selected'";} ?>><?php esc_html_e( 'Yes', 'pudla-recipe' ); ?></option>
            </select>
            </label>
        </p>
		<p>
			<label><b><?php esc_html_e( 'Note:', 'pudla-recipe' ); ?></b> 
			<?php 
			$plugin_link =  '<a rel="nofollow" href="https://wordpress.org/plugins/kk-star-ratings/" target="_blank" title="kk star rating">kk star rating plugin</a>';
			printf( wp_kses_post( __( 'It does not work untill %1$s installed.', 'pudla-recipe' ) ), $plugin_link );
			?></label>
		</p>

		<?php
	}
}