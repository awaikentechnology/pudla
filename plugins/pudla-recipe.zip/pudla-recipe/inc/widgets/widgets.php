<?php if ( ! defined( 'ABSPATH' ) ) exit;
require_once PUDLA_RECIPE_DIR . '/inc/widgets/popular-recipe.php';
require_once PUDLA_RECIPE_DIR . '/inc/widgets/about_widget.php';