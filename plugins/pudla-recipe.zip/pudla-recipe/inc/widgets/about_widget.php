<?php
/**
 * About me widget
 * Display your information on footer or sidebar
 *
 */
 
if ( ! defined( 'ABSPATH' ) ) exit;

// Register and load the widget
function pudla_about_load_widget() {
    register_widget( 'pudla_about_widget' );
}
add_action( 'widgets_init', 'pudla_about_load_widget' );

// Creating the widget 
class pudla_about_widget extends WP_Widget { 

	function __construct() {
		
		parent::__construct(
		 
		// Base ID of widget
		'pudla_about_widget', 
		 
		// Widget name will appear in UI
		esc_html__('.Pudla: About Me', 'pudla-recipe' ), 
		 
		// Widget description
		array( 'description' => esc_html__( 'A widget that displays an About Information.', 'pudla-recipe' ), ) 
		);
		
	}
	
	// Creating widget front-end
	public function widget( $args, $instance ) {
		
		extract( $args );
		$title     = apply_filters( 'widget_title', isset( $instance['title'] ) ? $instance['title'] : '' );
		echo wp_kses_post( $before_widget );

		if ( $title ) :
			echo wp_kses_post( $before_title . $title . $after_title );
		endif;
		?>
		<div class="about-me-widget">
			<figure>
				<img src="<?php echo esc_url( $instance['image'] ); ?>" alt="<?php echo esc_attr( $title ); ?>"/>
			</figure>
			
			<?php if ( $instance['description'] ) : ?>
				<p><?php echo wp_kses_post( $instance['description'] ); ?></p>
			<?php endif; ?>
			
			<?php if ( $instance['read_more_link'] ) : ?>
			<a target="_blank" class="author-read-more" href="<?php echo esc_url( $instance['read_more_link'] ); ?>"><?php _e( 'READ MORE ->', 'pudla-recipe' ); ?></a>
			<?php endif; ?>

		</div>
		<?php
		echo wp_kses_post( $after_widget );
		
	}
	
	//Updating widget replacing old instances with new
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['title']			=	strip_tags( $new_instance['title'] );
		$instance['image']      	=	strip_tags( $new_instance['image'] );
		$instance['description'] 	= 	$new_instance['description'];
		$instance['read_more_link']	=	strip_tags( $new_instance['read_more_link'] );

		return $instance;
	}
	
	// Widget Backend 
	public function form( $instance ) {
		/* Set up some default widget settings. */
		$defaults = array( 
			'title' 		 => esc_html__( 'About Me', 'pudla-recipe' ), 
			'image'			 => '',
			'description' 	 => '',
			'read_more_link' => '',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
	
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'pudla-recipe' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo sanitize_text_field( $instance['title'] ); ?>" />
		</p>
		
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'image' ) ); ?>"><?php esc_attr_e( 'Image URL:', 'pudla-recipe' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'image' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'image' ) ); ?>" value="<?php echo esc_url( $instance['image'] ); ?>" /><br />
			<small><?php esc_html_e( 'Insert your image URL. For best result use 150px width.', 'pudla-recipe' ); ?></small>
		</p>
		
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>"><?php esc_attr_e( 'About me text: ( you can use HTML here )', 'pudla-recipe' ); ?></label>
			<textarea class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'description' ) ); ?>" rows="6"><?php echo esc_textarea( $instance['description'] ); ?></textarea>
		</p>
		
	
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'read_more_link' ) ); ?>"><?php esc_attr_e( 'Read more Link:', 'pudla-recipe' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'read_more_link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'read_more_link' ) ); ?>" value="<?php echo sanitize_text_field( $instance['read_more_link'] ); ?>" />
		</p>

		<?php
	}

}