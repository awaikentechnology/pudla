<?php
/**
 * Customize for Pudla Recipe
 * @since 1.0
 */
 
if ( class_exists( 'Kirki' ) ) {
	
	Kirki::add_config( PUDLA_RECIPE_CONFIG_ID, array(
		'option_type' => 'theme_mod',
		'capability'  => 'edit_theme_options',
		'disable_output'  => true,
	) );
	
	$panel    = 'recipe_options';
	Kirki::add_panel( $panel, array(
		'priority' => 3,
		'title'    => __( 'Recipe Options', 'pudla-recipe' ),
	) );

	// Add Recipe Slug Options
	$section_priority = 10;
	$section    = 'recipe_slug_options';
	$field_priority = 1;
	Kirki::add_section( $section, array(
		'title'    => esc_html__( 'Slug Options', 'pudla-recipe' ),
		'panel'    => $panel,
		'priority' => $section_priority ++,
	) );
	
	Kirki::add_field( PUDLA_RECIPE_CONFIG_ID, array(
		'type'        => 'text',
		'settings'    => 'recipe_slug',
		'label'       => esc_html__( 'Recipe Slug', 'pudla-recipe' ),
		'description' => esc_html__( 'Recipe slug name used in the url of the Recipe post.  Default is recipe', 'pudla-recipe' ),
		'default'	  => 'recipe',
		'section'     => $section,
		'priority'    => $field_priority ++,
	) );

	Kirki::add_field( PUDLA_RECIPE_CONFIG_ID, array(
		'type'        => 'text',
		'settings'    => 'recipe_category_slug',
		'label'       => esc_html__( 'Recipe Category Slug', 'pudla-recipe' ),
		'description' => esc_html__( 'Recipe category slug name used in the url of the recipe category archives pages. Default is recipe-category', 'pudla-recipe' ),
		'default'	  => 'recipe-category',
		'section'     => $section,
		'priority'    => $field_priority ++,
	) );
	
	Kirki::add_field( PUDLA_RECIPE_CONFIG_ID, array(
		'type'        => 'text',
		'settings'    => 'recipe_tag_slug',
		'label'       => esc_html__( 'Recipe Tag Slug', 'pudla-recipe' ),
		'description' => esc_html__( 'Recipe Tag slug name used in the url of the recipe tag archives pages. Default is recipe-tag', 'pudla-recipe' ),
		'default'	  => 'recipe-tag',
		'section'     => $section,
		'priority'    => $field_priority ++,
	) );
	
	Kirki::add_field( PUDLA_RECIPE_CONFIG_ID, array(
		'type'        => 'text',
		'settings'    => 'recipe_cuisine_slug',
		'label'       => esc_html__( 'Recipe Cuisine Slug', 'pudla-recipe' ),
		'description' => esc_html__( 'Recipe cuisine slug name used in the url of the recipe cuisine archives pages. Default is cuisine', 'pudla-recipe' ),
		'default'	  => 'cuisine',
		'section'     => $section,
		'priority'    => $field_priority ++,
	) );
	
	Kirki::add_field( PUDLA_RECIPE_CONFIG_ID, array(
		'type'        => 'custom',
		'settings'    => 'recipe_slug_note',
		'default'     => '<div style="color: #555d66;font-weight: bold;font-size: 14px;display:inline-block;">' .esc_html__( 'Note :', 'pudla-recipe' ). '</div> '.esc_html__( 'After you\'ve changed value of above any slug, don\'t forget to update permalinks from "Settings &gt; Permalinks" page.', 'pudla-recipe' ) ,
		'section' 	  => $section,
		'priority'    => $field_priority ++,
	) );
	
}