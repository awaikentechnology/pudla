<?php
/**
 * Plugin Name: Pudla Recipe
 * Description: Recipe Plugin for Pudla theme.
 * Version: 1.0
 * Author: Awaiken
 * Author URI: https://themeforest.net/user/awaiken
 * Text Domain: pudla-recipe
 * Plugin URI: https://awaikenthemes.com/
**/

define( 'PUDLA_RECIPE_CONFIG_ID', 'pudla_recipe' );
define( 'PUDLA_RECIPE_DIR', plugin_dir_path( __FILE__ ) );
define( 'PUDLA_RECIPE_URL', plugin_dir_url( __FILE__ ) );
 
/**
 * Load plugin textdomain.
 *
 * @since 1.0
 */
 
add_action( 'plugins_loaded', 'pudla_recipe_load_textdomain' );
function pudla_recipe_load_textdomain() {
	load_plugin_textdomain( 'pudla-recipe', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}

/**
* Register Recipe post type
*/
add_action( 'init', 'pudla_create_recipe_post_type' );
function pudla_create_recipe_post_type() {
	$recipe_slug = get_theme_mod( 'recipe_slug', 'recipe' );
	$labels = array(
		'name'               => __( 'Recipes', 'pudla-recipe' ),
		'singular_name'      => __( 'Recipe', 'pudla-recipe' ),
		'add_new'            => __( 'Add Recipe', 'pudla-recipe' ),
		'add_new_item'       => __( 'Add New Recipe', 'pudla-recipe' ),
		'edit_item'          => __( 'Edit Recipe', 'pudla-recipe' ),
		'new_item'           => __( 'New Recipe', 'pudla-recipe' ),
		'all_items'          => __( 'All Recipes', 'pudla-recipe' ),
		'view_item'          => __( 'View Recipe', 'pudla-recipe' ),
		'search_items'       => __( 'Search Recipe', 'pudla-recipe' ),
		'not_found'          => __( 'No Recipes found', 'pudla-recipe' ),
		'not_found_in_trash' => __( 'No Recipes found in Trash', 'pudla-recipe' ),
		'parent_item_colon'  => '',
		'menu_name'          => __( 'Recipes', 'pudla-recipe' ),
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => $recipe_slug ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 5,
		'show_in_rest'       => true,
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments', 'post-formats' )
	);

	register_post_type( 'pudla_recipe', $args );
}

/**
* Register Recipe Categories
*/
add_action( 'init', 'pudla_register_recipe_category' );
function pudla_register_recipe_category() {
	
	$labels = array(
		'name'              => __( 'Recipe Categories', 'pudla-recipe' ),
		'singular_name'     => __( 'Category', 'pudla-recipe' ),
		'search_items'      => __( 'Search Recipe Categories', 'pudla-recipe' ),
		'all_items'         => __( 'All Recipe Categories', 'pudla-recipe' ),
		'parent_item'       => __( 'Parent Recipe Category', 'pudla-recipe' ),
		'parent_item_colon' => __( 'Parent Recipe Category:', 'pudla-recipe' ),
		'edit_item'         => __( 'Edit Recipe Category', 'pudla-recipe' ),
		'update_item'       => __( 'Update Recipe Category', 'pudla-recipe' ),
		'add_new_item'      => __( 'Add New Recipe Category', 'pudla-recipe' ),
		'new_item_name'     => __( 'New Recipe Category Name', 'pudla-recipe' ),
		'menu_name'         => __( 'Category', 'pudla-recipe' )
	);
	
	$recipe_category_slug = get_theme_mod( 'recipe_category_slug', 'recipe-category' );
	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => $recipe_category_slug )
	);

	register_taxonomy( 'recipe_category', array( 'pudla_recipe' ), $args );
}

/**
* Register Recipe Tag
*/
add_action( 'init', 'pudla_register_recipe_tag' );
function pudla_register_recipe_tag() {

	$labels = array(
		'name'              => __( 'Recipe Tags', 'pudla-recipe' ),
		'singular_name'     => __( 'Tag', 'pudla-recipe' ),
		'search_items'      => __( 'Search Tag', 'pudla-recipe' ),
		'all_items'         => __( 'All Tags', 'pudla-recipe' ),
		'parent_item'       => null,
		'parent_item_colon' => null,
		'edit_item'         => __( 'Edit Recipe Tag', 'pudla-recipe' ),
		'update_item'       => __( 'Update Recipe Tag', 'pudla-recipe' ),
		'add_new_item'      => __( 'Add New Recipe Tag', 'pudla-recipe' ),
		'new_item_name'     => __( 'New Recipe Tag Name', 'pudla-recipe' ),
		'menu_name'         => __( 'Tags', 'pudla-recipe' )
	);

	$recipe_tag_slug = get_theme_mod( 'recipe_tag_slug', 'recipe-tag' );
	$args = array(
		'hierarchical'      => false,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => $recipe_tag_slug )
	);

	register_taxonomy( 'recipe_tag', array( 'pudla_recipe' ), $args );

	//Cuisine
	$labels = array(
		'name'              => __( 'Recipe Cuisine', 'pudla-recipe' ),
		'singular_name'     => __( 'Cuisine', 'pudla-recipe' ),
		'search_items'      => __( 'Search Cuisine', 'pudla-recipe' ),
		'all_items'         => __( 'All Cuisine', 'pudla-recipe' ),
		'parent_item'       => null,
		'parent_item_colon' => null,
		'edit_item'         => __( 'Edit Cuisine', 'pudla-recipe' ),
		'update_item'       => __( 'Update Cuisine', 'pudla-recipe' ),
		'add_new_item'      => __( 'Add New Cuisine', 'pudla-recipe' ),
		'new_item_name'     => __( 'New Cuisine Name', 'pudla-recipe' ),
		'menu_name'         => __( 'Cuisine', 'pudla-recipe' )
	);

	$recipe_cuisine_slug = get_theme_mod( 'recipe_cuisine_slug', 'cuisine' );
	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => $recipe_cuisine_slug )
	);

	register_taxonomy( 'recipe_cuisine', array( 'pudla_recipe' ), $args );
}

/**
 * Add Filter by taxonomy option to pudla_recipe post type
 */

add_action('restrict_manage_posts', 'pudla_filter_post_type_by_taxonomy');
function pudla_filter_post_type_by_taxonomy() {
	global $typenow;
	$post_type = 'pudla_recipe'; 
	$taxonomy  = 'recipe_category'; 
	if ($typenow == $post_type) {
		$selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
		$info_taxonomy = get_taxonomy($taxonomy);
		wp_dropdown_categories(array(
			'show_option_all' => __("Show All {$info_taxonomy->label}"),
			'taxonomy'        => $taxonomy,
			'name'            => $taxonomy,
			'orderby'         => 'name',
			'selected'        => $selected,
			'show_count'      => true,
			'hide_empty'      => true,
		));
	};
}

add_filter('parse_query', 'pudla_convert_id_to_term_in_query');
function pudla_convert_id_to_term_in_query($query) {
	global $pagenow;
	$post_type = 'pudla_recipe'; 
	$taxonomy  = 'recipe_category'; 
	$q_vars    = &$query->query_vars;
	if ( $pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
		$term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
		$q_vars[$taxonomy] = $term->slug;
	}
}

/**
 * Merge recipe detail box with content using shortcode [pudla_recipe_detail_box]
 */

function pudla_add_shortcode( $content ) {
    if ( is_single() && 'pudla_recipe' == get_post_type() ) {
		$custom_content = '';
		if( true == get_theme_mod( 'recipe_detail_box_after_post_content', true ) ) {
			$custom_content = '[pudla_recipe_detail_box]';
		}
        $content .= $custom_content;
    }
    return $content;
}
add_filter( 'the_content', 'pudla_add_shortcode', 8 );


/**
 * Include files
 */
require_once( PUDLA_RECIPE_DIR . '/inc/customize.php' );
require_once( PUDLA_RECIPE_DIR . '/inc/custom-field.php' );
require_once( PUDLA_RECIPE_DIR . '/inc/shortcodes.php' );
require_once( PUDLA_RECIPE_DIR . '/inc/widgets/widgets.php' );